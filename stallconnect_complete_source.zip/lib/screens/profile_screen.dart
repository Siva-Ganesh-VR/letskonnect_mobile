import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/api_client.dart';
import 'login_screen.dart';
import 'privacy_policy_screen.dart';
import 'terms_conditions_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _stallOwner;
  int _totalEvents = 0;
  int _totalLeadsCount = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() => _loading = true);
    
    final stallJson = await ApiClient.getStallOwnerJson();
    if (stallJson != null) _stallOwner = jsonDecode(stallJson);

    final result = await ApiClient.call(
      () => ApiClient.dio.get('/api/v1/stall_owner/dashboard'),
    );

    if (result.success && result.data is Map) {
      final data = result.data as Map<String, dynamic>;
      if (data['events'] is List) {
        _totalEvents = (data['events'] as List).length;
      }
      if (data['summary'] != null && data['summary']['total'] != null) {
        _totalLeadsCount = data['summary']['total'];
      }
    }

    if (mounted) setState(() => _loading = false);
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }

  Future<void> _signOut() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w700)),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sign Out', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      // Call server-side sign_out before clearing local token
      await ApiClient.call(() => ApiClient.dio.delete('/api/v1/stall/sign_out'));
      await ApiClient.deleteToken();
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
            (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primary)));
    }

    final name     = _stallOwner?['name'] ?? _stallOwner?['company_name'] ?? 'Stall Owner';
    final company  = _stallOwner?['company_name'] ?? _stallOwner?['business_name'] ?? '';
    final mobile   = _stallOwner?['mobile_number'] ?? '';
    final category = _stallOwner?['category'] ?? 'General';

    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text('Profile', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 2))],
              ),
              child: Column(
                children: [
                  Container(
                    width: 64, height: 64,
                    decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.15), shape: BoxShape.circle),
                    child: Center(
                      child: Text(_initials(name),
                          style: const TextStyle(color: AppColors.primary, fontSize: 24, fontWeight: FontWeight.w700)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFF0F172A))),
                  const SizedBox(height: 4),
                  if (company.isNotEmpty)
                    Text(company, style: const TextStyle(fontSize: 14, color: Color(0xFF64748B))),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                    child: Text('Total Events : $_totalEvents', style: const TextStyle(color: AppColors.primary, fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 2))],
              ),
              child: Column(
                children: [
                  _InfoRow(icon: Icons.phone_rounded, label: 'Mobile', value: mobile, isFirst: true),
                  const Divider(height: 1, color: Color(0xFFF1F5F9), indent: 56),
                  _InfoRow(icon: Icons.category_rounded, label: 'Category', value: category),
                  const Divider(height: 1, color: Color(0xFFF1F5F9), indent: 56),
                  _InfoRow(icon: Icons.people_alt_rounded, label: 'Total Leads', value: '$_totalLeadsCount', isLast: true),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 2))],
              ),
              child: Column(
                children: [
                  _LegalRow(
                    icon: Icons.privacy_tip_rounded,
                    label: 'Privacy Policy',
                    onTap: () => launchUrl(
                      Uri.parse('https://stallconnect.in/privacy.html'),
                      mode: LaunchMode.externalApplication,
                    ),
                    isFirst: true,
                  ),

                  const Divider(
                    height: 1,
                    color: Color(0xFFF1F5F9),
                    indent: 56,
                  ),

                  _LegalRow(
                    icon: Icons.description_rounded,
                    label: 'Terms & Conditions',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const TermsConditionsScreen(),
                      ),
                    ),
                  ),

                  const Divider(
                    height: 1,
                    color: Color(0xFFF1F5F9),
                    indent: 56,
                  ),

                  _LegalRow(
                    icon: Icons.delete_outline_rounded,
                    label: 'Delete My Account',
                    onTap: () => launchUrl(
                      Uri.parse(
                        'mailto:support@stallconnect.in?subject=Account%20Deletion%20Request',
                      ),
                      mode: LaunchMode.externalApplication,
                    ),
                    isLast: true,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: OutlinedButton.icon(
                onPressed: _signOut,
                icon: const Icon(Icons.logout_rounded, color: Colors.red, size: 18),
                label: const Text('Sign Out', style: TextStyle(color: Colors.red, fontSize: 15, fontWeight: FontWeight.w700)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.red, width: 1.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool isFirst;
  final bool isLast;
  const _InfoRow({required this.icon, required this.label, required this.value, this.isFirst = false, this.isLast = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20, top: isFirst ? 18 : 14, bottom: isLast ? 18 : 14),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: const Color(0xFF64748B), size: 18),
          ),
          const SizedBox(width: 16),
          Text(label, style: const TextStyle(fontSize: 14, color: Color(0xFF64748B))),
          const Spacer(),
          Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF0F172A))),
        ],
      ),
    );
  }
}

class _LegalRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isFirst;
  final bool isLast;
  const _LegalRow({required this.icon, required this.label, required this.onTap, this.isFirst = false, this.isLast = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.vertical(
        top: isFirst ? const Radius.circular(16) : Radius.zero,
        bottom: isLast ? const Radius.circular(16) : Radius.zero,
      ),
      child: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: isFirst ? 18 : 14, bottom: isLast ? 18 : 14),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: const Color(0xFF64748B), size: 18),
            ),
            const SizedBox(width: 16),
            Text(label, style: const TextStyle(fontSize: 14, color: Color(0xFF0F172A), fontWeight: FontWeight.w500)),
            const Spacer(),
            const Icon(Icons.chevron_right_rounded, color: Color(0xFF94A3B8), size: 20),
          ],
        ),
      ),
    );
  }
}
